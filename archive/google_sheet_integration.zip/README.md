# Интеграция с Google Таблицами

Проект на Python: доступ к Google Sheets через **сервисный аккаунт**, модуль CRUD (`google_sheets.py`) и десктоп-приложение на **Tkinter** для симуляции отчётов и записи на **новый лист** книги (`report_app.py`, `report_generator.py`).

## Требования

- Python 3.10+ (рекомендуется актуальная ветка 3.x)
- Учётная запись Google и таблица в формате **Google Sheets** (не только файл Excel на Диске)
- JSON-ключ **сервисного аккаунта** с включённым API **Google Sheets**

## Установка

```bash
cd google_sheet_integration
python3 -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Настройка

1. Скопируйте пример переменных окружения и отредактируйте значения:

   ```bash
   cp .env.example .env
   ```

2. В `.env` задайте:

   | Переменная | Описание |
   |------------|----------|
   | `CREDENTIALS_PATH` | Имя JSON в корне проекта или **абсолютный** путь к ключу |
   | `SPREADSHEET_ID` | ID книги из URL: `https://docs.google.com/spreadsheets/d/<ID>/edit` |

3. В Google Cloud Console для проекта включите **Google Sheets API** и создайте ключ сервисного аккаунта (тип JSON).

4. Откройте нужную таблицу → **Доступ** → добавьте **email сервисного аккаунта** (поле `client_email` в JSON) с правом **Редактор**.

## Структура репозитория

| Файл | Назначение |
|------|------------|
| `google_sheets.py` | Класс `GoogleSheetsClient`: чтение, запись ячеек и диапазонов, очистка, добавление строки, удаление строки/листа, создание листа, `batch_update` для форматирования |
| `report_generator.py` | Случайные данные отчёта, вёрстка и форматирование листа, `export_report_to_sheets()` |
| `report_app.py` | Окно Tkinter: период (дата с / по), подразделение, тип отчёта → запись на новый лист |
| `requirements.txt` | Зависимости PyPI |
| `.env.example` | Шаблон переменных окружения |

## Запуск

Проверка чтения первого листа (из консоли):

```bash
python google_sheets.py
```

GUI симулятора отчётов:

```bash
python report_app.py
```

Каждое успешное нажатие кнопки создаёт **новый лист** в книге `SPREADSHEET_ID` с оформлением (объединённые ячейки заголовка, границы, ширина колонок, итоговая строка).

## Использование `GoogleSheetsClient` в коде

```python
from google_sheets import GoogleSheetsClient

client = GoogleSheetsClient()
# или явно:
# client = GoogleSheetsClient(spreadsheet_id="...", credentials_path="/path/key.json")

rows = client.read_all_values()
client.update_cell("A1", "Текст")
client.write_range("A1:C2", [["a", "b", "c"], [1, 2, 3]])
name, sheet_id = client.add_sheet("Мой лист")
client.batch_update([...])  # запросы в формате Google Sheets API batchUpdate
```

При чтении из ячеек неразрывный пробел `\xa0` (часто из денежного формата) в строках **нормализуется** (убирается).

## Устранение неполадок

- **403 / 404** при обращении к таблице — проверьте доступ сервисного аккаунта и правильность `SPREADSHEET_ID`.
- **400** с текстом вроде *This operation is not supported for this document* — файл должен быть именно **Google Таблицей**; при необходимости сохраните Excel как Google Sheets через меню файла.
- **Файл ключа не найден** — проверьте `CREDENTIALS_PATH` и расположение JSON относительно каталога проекта (если указано только имя файла, оно ищется рядом с `google_sheets.py`).
